# src/recommender.py

import pandas as pd
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import linear_kernel
import joblib
import os

# Paths
DATA_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), "data", "movies.csv")
MODEL_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), "models", "tfidf_sim.pkl")


def load_movies(path=DATA_PATH):
    """Load and prepare movie dataset."""
    df = pd.read_csv(path)

    # Ensure these columns exist
    for col in ['movieId', 'title', 'overview', 'genres']:
        if col not in df.columns:
            df[col] = ""

    # Create combined content
    df['content'] = (
        df['title'].astype(str) + " " +
        df['genres'].astype(str) + " " +
        df['overview'].astype(str)
    )

    df = df.fillna("").reset_index(drop=True)
    return df


def build_tfidf_matrix(df, max_features=20000):
    """Build TF-IDF matrix from movie content."""
    tfidf = TfidfVectorizer(
        stop_words='english',
        max_features=max_features
    )
    tfidf_matrix = tfidf.fit_transform(df['content'])
    return tfidf, tfidf_matrix


def build_and_save_model(save_path=MODEL_PATH):
    """Build similarity model and save it."""
    df = load_movies()
    tfidf, tfidf_matrix = build_tfidf_matrix(df)

    # Cosine similarity using linear_kernel (optimized)
    cosine_sim = linear_kernel(tfidf_matrix, tfidf_matrix)

    # Map titles to index
    indices = pd.Series(df.index, index=df['title'].str.lower()).drop_duplicates()

    # Model dictionary
    model = {
        'df': df,
        'tfidf': tfidf,
        'cosine_sim': cosine_sim,
        'indices': indices
    }

    # Ensure folder exists
    os.makedirs(os.path.dirname(save_path), exist_ok=True)

    # Save model
    joblib.dump(model, save_path)
    print(f"Model saved to {save_path}")
    return model


def load_model(path=MODEL_PATH):
    """Load saved model or build it if missing."""
    if not os.path.exists(path):
        return build_and_save_model(path)

    model = joblib.load(path)
    return model


def get_recommendations(title, model=None, top_n=10):
    """Return top-N recommended movies based on cosine similarity."""
    if model is None:
        model = load_model()

    df = model["df"]
    cosine_sim = model["cosine_sim"]
    indices = model["indices"]

    title_lower = title.lower()

    # If exact title not found, try partial match
    if title_lower not in indices:
        matches = df[df['title'].str.lower().str.contains(title_lower)]
        if len(matches) > 0:
            idx = matches.index[0]
        else:
            raise ValueError(f"Movie '{title}' not found in dataset.")
    else:
        idx = indices[title_lower]

    # Get similarity scores
    sim_scores = list(enumerate(cosine_sim[int(idx)]))
    sim_scores = sorted(sim_scores, key=lambda x: x[1], reverse=True)

    # Skip the same movie (first one)
    sim_scores = sim_scores[1: top_n + 1]

    movie_indices = [i[0] for i in sim_scores]

    return df.iloc[movie_indices].copy()


# Run this file directly to generate the model
if __name__ == "__main__":
    build_and_save_model()
