# src/app.py
import streamlit as st
from pathlib import Path
import sys
sys.path.append(str(Path(__file__).resolve().parents[1] / "src"))

from recommender import load_model, get_recommendations

st.set_page_config(page_title="Movie Recommender", layout="wide")

st.title("🎬 Movie Recommendation System")
st.write("Enter a movie title to get similar movie recommendations.")

# Load model once
@st.cache_resource
def get_model():
    return load_model()
model = get_model()

title_input = st.text_input("Movie title", value="")
top_n = st.slider("Number of recommendations", 3, 20, 10)

if st.button("Recommend") or title_input:
    if not title_input.strip():
        st.warning("Please type a movie title.")
    else:
        try:
            recs = get_recommendations(title_input, model=model, top_n=top_n)
            st.subheader(f"Recommendations for: **{title_input}**")
            for i, row in recs.iterrows():
                st.markdown(f"**{row['title']}** — _{row.get('genres','')}_")
                if 'overview' in row and isinstance(row['overview'], str) and row['overview'].strip():
                    st.write(row['overview'])
                st.write("---")
        except Exception as e:
            st.error(str(e))
